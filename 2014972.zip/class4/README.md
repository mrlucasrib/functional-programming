# class4

Exercises in [app/Main.hs](app/Main.hs)